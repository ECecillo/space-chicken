package fr.univlyon1.m1if.m1if13.users.model;

public enum Species {
    COWBOY, POULE
}
