import map from './map.js';
import form from './form.js';

const mymap = map();
const myform = form(mymap);
